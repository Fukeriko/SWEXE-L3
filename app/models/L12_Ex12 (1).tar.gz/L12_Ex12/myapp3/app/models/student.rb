class Student < ApplicationRecord
    VALID_NUM = /\d{2}111[12345]\d{4}/
    validates :num, presence: true, format: { with: VALID_NUM }
    validates :name, presence: true
    VALID_MAIL = /\A[\w+\-.]+@[a-z\d\-.]+\.[a-z]+\z/
    validates :mail, presence: true, format: { with: VALID_MAIL }
end
