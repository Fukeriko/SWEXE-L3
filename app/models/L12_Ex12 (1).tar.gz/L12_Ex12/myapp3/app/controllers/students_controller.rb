class StudentsController < ApplicationController
  def index
    @students = Student.all
  end
  def new
    @student = Student.new
  end
  def create
    @student = Student.new(num: params[:student][:num], name: params[:student][:name], mail: params[:student][:mail])
    if @student.save  # 成功時
      flash[:notice] = '1レコード追加しました'
      redirect_to '/'
    else
      render 'new' # create.html.erb ではなく，new.html.erbを利用.
    end
  end
  def destroy
    student = Student.find(params[:id])
    student.destroy
    redirect_to '/'
  end
  def show
    @student = Student.find(params[:id])
  end
  def edit
    @student = Student.find(params[:id])
  end
  def update
    @student = Student.find(params[:id])
    if @student.update(num: params[:student][:num], name: params[:student][:name], mail: params[:student][:mail])
      flash[:notice] = '1レコードを編集しました'
      redirect_to '/'
    else
      render 'edit' # update.html.erb ではなく edit.html.erb を利用．
    end
  end
end